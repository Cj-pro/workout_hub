CREATE TABLE workouts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  description TEXT NOT NULL
);

INSERT INTO workouts (name, description) VALUES
('Beginner Program', 'Start your journey with basic exercises.'),
('Intermediate Program', 'Level up your fitness routine.'),
('Advanced Program', 'Challenge yourself with advanced moves.');
