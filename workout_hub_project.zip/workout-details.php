<?php
include "db.php";
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$sql = "SELECT * FROM workouts WHERE id = $id";
$result = $conn->query($sql);
$workout = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?php echo $workout ? htmlspecialchars($workout['name']) : 'Workout Details'; ?></title>
  <link rel="stylesheet" href="styles.css" />
</head>
<body>
  <header>
    <h1>Workout Hub</h1>
    <nav>
      <a href="index.php">Home</a>
      <a href="workouts.php">Workouts</a>
      <a href="about.php">About</a>
      <a href="contact.php">Contact</a>
    </nav>
  </header>

  <main>
    <?php if ($workout): ?>
      <h2><?php echo htmlspecialchars($workout['name']); ?></h2>
      <p><?php echo htmlspecialchars($workout['description']); ?></p>
    <?php else: ?>
      <p>Workout not found.</p>
    <?php endif; ?>
  </main>

  <footer>
    <p>© 2025 Workout Hub</p>
  </footer>
</body>
</html>