<?php
$servername = "localhost";
$username = "id_yourusername";  // Replace with your DB username
$password = "yourpassword";     // Replace with your DB password
$dbname = "id_yourdbname";      // Replace with your DB name

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
?>