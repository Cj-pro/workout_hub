<?php include "db.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Workout Hub - Home</title>
  <link rel="stylesheet" href="styles.css" />
</head>
<body>
  <header>
    <h1>Workout Hub</h1>
    <nav>
      <a href="index.php">Home</a>
      <a href="workouts.php">Workouts</a>
      <a href="about.php">About</a>
      <a href="contact.php">Contact</a>
    </nav>
  </header>

  <main class="hero">
    <h2>Welcome to Workout Hub!</h2>
    <p>Find the perfect workout plan for your fitness goals.</p>

    <?php
    $sql = "SELECT name, description FROM workouts LIMIT 3";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        echo "<h3>Featured Workouts:</h3><ul>";
        while ($row = $result->fetch_assoc()) {
            echo "<li><strong>" . htmlspecialchars($row['name']) . ":</strong> " 
                 . htmlspecialchars($row['description']) . "</li>";
        }
        echo "</ul>";
    } else {
        echo "<p>No workouts found. Add some in your database.</p>";
    }
    ?>
  </main>

  <footer>
    <p>© 2025 Workout Hub</p>
  </footer>
</body>
</html>