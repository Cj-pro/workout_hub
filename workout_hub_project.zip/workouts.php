<?php include "db.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Workout Programs</title>
  <link rel="stylesheet" href="styles.css" />
</head>
<body>
  <header>
    <h1>Workout Hub</h1>
    <nav>
      <a href="index.php">Home</a>
      <a href="workouts.php">Workouts</a>
      <a href="about.php">About</a>
      <a href="contact.php">Contact</a>
    </nav>
  </header>

  <main>
    <h2>Workout Programs</h2>
    <div class="workout-grid">
    <?php
    $sql = "SELECT id, name, description FROM workouts";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo '<a class="card" href="workout-details.php?id=' . $row['id'] . '">
                    <h3>' . htmlspecialchars($row['name']) . '</h3>
                    <p>' . htmlspecialchars($row['description']) . '</p>
                  </a>';
        }
    } else {
        echo "<p>No workouts found.</p>";
    }
    ?>
    </div>
  </main>

  <footer>
    <p>© 2025 Workout Hub</p>
  </footer>
</body>
</html>